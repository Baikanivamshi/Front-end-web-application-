// Focus the first input on load
window.addEventListener('DOMContentLoaded', () => {
  const first = document.getElementById('ch1');
  if (first) {
    first.focus();
  }

  // Enforce inputs: credit hours = integers; grade = single uppercase letter A/B/C/D/F
  const digitOnly = /[^0-9]/g;
  const allowedGrades = new Set(['A','B','C','D','F']);
  [1,2,3,4,5].forEach(i => {
    const ch = document.getElementById('ch'+i);
    const g  = document.getElementById('g'+i);
    if (ch) {
      ch.addEventListener('input', () => {
        ch.value = ch.value.replace(digitOnly, ''); // keep digits only
      });
    }
    if (g) {
      g.addEventListener('input', () => {
        const up = g.value.toUpperCase();
        const one = up.slice(0,1);
        g.value = allowedGrades.has(one) ? one : (one && !allowedGrades.has(one) ? '' : '');
      });
    }
  });
});

// Map letter grades to points
function gradeToPoints(letter) {
  if (!letter) return null;
  const l = String(letter).trim().toUpperCase();
  const map = {
    'A': 4.0,
    'B': 3.0,
    'C': 2.0,
    'D': 1.0,
    'F': 0.0
  };
  return map.hasOwnProperty(l) ? map[l] : null;
}

// Calculate GPA based on up to 5 entries; require at least 2 valid entries
function calculateGPA() {
  const ch = [1,2,3,4,5].map(i => (document.getElementById('ch'+i).value || '').trim());
  const gr = [1,2,3,4,5].map(i => (document.getElementById('g'+i).value || '').trim().toUpperCase().slice(0,1));

  let totalCredits = 0;
  let totalPoints = 0;
  let validCount = 0;

  for (let i = 0; i < 5; i++) {
    // integer-only credit hours
    const hoursStr = ch[i];
    const isInteger = /^\d+$/.test(hoursStr);
    const hours = isInteger ? parseInt(hoursStr, 10) : NaN;
    const pts = gradeToPoints(gr[i]);
    if (!isNaN(hours) && hours > 0 && pts !== null) {
      totalCredits += hours;
      totalPoints += (pts * hours);
      validCount++;
    }
  }

  if (validCount < 2 || totalCredits === 0) {
    const out = document.getElementById('avgGpa');
    if (out) {
      out.value = '';
    }
    alert('Please enter at least 2 valid course entries (credit hours and letter grade).');
    return;
  }

  const gpa = totalPoints / totalCredits;
  const out = document.getElementById('avgGpa');
  if (out) {
    out.value = gpa.toFixed(2);
  }
}

// Reset all input boxes
function resetGPA() {
  [1,2,3,4,5].forEach(i => {
    const a = document.getElementById('ch'+i);
    const b = document.getElementById('g'+i);
    if (a) a.value = '';
    if (b) b.value = '';
  });
  const out = document.getElementById('avgGpa');
  if (out) {
    out.value = '';
  }
  const first = document.getElementById('ch1');
  if (first) {
    first.focus();
  }
}

// Expose to global
window.calculateGPA = calculateGPA;
window.resetGPA = resetGPA;
